# Make arrays of Symbols sortable
class Symbol
    include Comparable

    def <=>(other)
        self.to_s <=> other.to_s
    end
end

